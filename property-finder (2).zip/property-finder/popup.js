/* ===========================================================
   PROPERTY OWNER FINDER · popup.js
   =========================================================== */

const $ = id => document.getElementById(id);

/* ===========================================================
   ENTITY DETECTION (LLC vs person)
   =========================================================== */

const ENTITY_KEYWORDS = [
  'LLC', 'L.L.C', 'INC', 'CORP', 'CORPORATION', 'TRUST', 'LP', 'L.P',
  'LLP', 'LTD', 'PLLC', 'CO.', 'COMPANY', 'LLLP', 'PARTNERSHIP',
  'ASSOCIATION', 'HOLDINGS', 'PROPERTIES', 'GROUP', 'ENTERPRISES',
  'INVESTMENTS', 'REALTY', 'CAPITAL', 'VENTURES', 'PARTNERS',
  'FOUNDATION', 'SOCIETY'
];

function isLikelyEntity(name) {
  if (!name) return false;
  const upper = name.toUpperCase();
  return ENTITY_KEYWORDS.some(kw => {
    const escaped = kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const pattern = new RegExp(`\\b${escaped}\\b`);
    return pattern.test(upper);
  });
}

/* ===========================================================
   SEARCH URL BUILDERS
   =========================================================== */

function buildSearchURL(source, ownerName, mailingAddress, cityState) {
  const name = (ownerName || '').trim();
  const enc = encodeURIComponent;
  const cleanCity = (cityState || '').trim();

  // Extract city + state separately
  const cityMatch = cleanCity.match(/^([^,]+),?\s*([A-Z]{2})/i);
  const city = cityMatch ? cityMatch[1].trim() : cleanCity;
  const state = cityMatch ? cityMatch[2].toUpperCase() : '';

  switch (source) {
    case 'sunbiz':
      // Florida Division of Corporations entity search
      return `https://search.sunbiz.org/Inquiry/CorporationSearch/SearchResults?inquiryType=EntityName&searchTerm=${enc(name)}`;

    case 'google':
      // Smart query — entity vs person gets different framing
      if (isLikelyEntity(name)) {
        return `https://www.google.com/search?q=${enc(`"${name}" (manager OR principal OR "registered agent" OR owner) ${city || ''} phone`)}`;
      }
      return `https://www.google.com/search?q=${enc(`"${name}" ${cleanCity} (phone OR contact OR email)`)}`;

    case 'truepeople': {
      let url = `https://www.truepeoplesearch.com/results?name=${enc(name)}`;
      if (cleanCity) url += `&citystatezip=${enc(cleanCity)}`;
      return url;
    }

    case 'fastpeople': {
      const slug = name.toLowerCase().replace(/[^a-z\s]/g, '').trim().replace(/\s+/g, '-');
      const citySlug = cleanCity.toLowerCase().replace(/[^a-z\s,]/g, '').replace(/[\s,]+/g, '-').replace(/-+/g, '-');
      if (slug && citySlug) {
        return `https://www.fastpeoplesearch.com/name/${enc(slug)}_${enc(citySlug)}`;
      }
      return `https://www.fastpeoplesearch.com/name/${enc(slug || name)}`;
    }

    case 'thatsthem': {
      const slug = name.replace(/\s+/g, '-');
      let url = `https://thatsthem.com/name/${enc(slug)}`;
      if (state) url += `/${state}`;
      return url;
    }

    case 'whitepages': {
      const nameSlug = name.replace(/\s+/g, '-');
      const citySlug = cleanCity.replace(/,/g, '').replace(/\s+/g, '-');
      if (citySlug) return `https://www.whitepages.com/name/${enc(nameSlug)}/${enc(citySlug)}`;
      return `https://www.whitepages.com/name/${enc(nameSlug)}`;
    }

    case 'linkedin':
      return `https://www.linkedin.com/search/results/people/?keywords=${enc(name + (cleanCity ? ' ' + cleanCity : ''))}`;

    case 'facebook':
      return `https://www.facebook.com/search/people/?q=${enc(name + (cleanCity ? ' ' + cleanCity : ''))}`;

    default:
      return null;
  }
}

/* ===========================================================
   SEARCH ACTIONS
   =========================================================== */

async function openSearch(source) {
  const ownerName = $('ownerName').value.trim();
  if (!ownerName) {
    flashHint('extractHint', 'Enter an owner name first.', false);
    return;
  }
  const mailingAddress = $('mailingAddress').value.trim();
  const cityState = $('cityState').value.trim();

  const url = buildSearchURL(source, ownerName, mailingAddress, cityState);
  if (url) {
    chrome.tabs.create({ url, active: false });
    saveToHistory(ownerName, source);
  }
}

async function openAllSources() {
  const ownerName = $('ownerName').value.trim();
  if (!ownerName) {
    flashHint('extractHint', 'Enter an owner name first.', false);
    return;
  }
  const isEntity = isLikelyEntity(ownerName);
  // Entities → Sunbiz first, then people-search after Sunbiz reveals the principal
  // Persons → straight to all people-search engines
  const sources = isEntity
    ? ['sunbiz', 'google', 'truepeople', 'fastpeople', 'thatsthem', 'linkedin']
    : ['google', 'truepeople', 'fastpeople', 'thatsthem', 'whitepages', 'linkedin', 'facebook'];

  for (const source of sources) {
    await openSearch(source);
    await new Promise(r => setTimeout(r, 80));
  }
}

/* ===========================================================
   CONTENT SCRIPT — runs in the page context
   =========================================================== */

// This entire function gets serialized and injected into the active tab.
function pageExtractor() {

  /* ---- Owner / address from common tax-card layouts ---- */
  function extractGeneric() {
    const result = {};
    const labelMap = {
      ownerName: ['owner name', 'owner names', 'owner(s)', 'owner', 'current owner', 'property owner', 'taxpayer name', 'taxpayer', 'grantee', 'title holder'],
      mailingAddress: ['mailing address', 'owner mailing address', 'owner address', 'tax bill mail to', 'tax mailing'],
      propertyAddress: ['site address', 'property address', 'physical address', 'situs address', 'situs', 'location', 'street address']
    };

    const allElements = document.querySelectorAll('th, td, dt, dd, label, div, span, p, strong, b');

    for (const [key, labels] of Object.entries(labelMap)) {
      if (result[key]) continue;
      for (const el of allElements) {
        const raw = el.textContent.trim();
        if (raw.length > 80) continue; // labels are short
        const text = raw.toLowerCase().replace(/[:*]+$/, '').trim();
        if (labels.some(l => text === l || text === l + ':')) {
          const value = findNearbyValue(el, labels);
          if (value) {
            result[key] = value.trim();
            break;
          }
        }
      }
    }

    // Some tax cards put "Owner: John Smith" inline in a single text block
    if (!result.ownerName) {
      const texts = Array.from(document.querySelectorAll('p, div, span, td')).map(e => e.textContent.trim());
      for (const t of texts) {
        if (t.length > 200) continue;
        const m = t.match(/^Owner(?:\s*Name)?\s*[:]\s*(.+)$/i);
        if (m && m[1].trim().length < 100) { result.ownerName = m[1].trim(); break; }
      }
    }

    // Split mailing address into street + city/state
    if (result.mailingAddress) {
      const split = splitAddress(result.mailingAddress);
      if (split) {
        result.mailingAddress = split.street;
        result.cityState = split.cityState;
      }
    }

    return result;
  }

  function findNearbyValue(labelEl, labelsToAvoid) {
    const isLabel = txt => labelsToAvoid.some(l =>
      txt.toLowerCase().replace(/[:*]+$/, '').trim() === l
    );

    // 1. Same row, next cell
    if (labelEl.parentElement && labelEl.parentElement.tagName === 'TR') {
      const cells = Array.from(labelEl.parentElement.querySelectorAll('td, th'));
      const idx = cells.indexOf(labelEl);
      if (idx >= 0 && cells[idx + 1]) {
        const t = cells[idx + 1].textContent.trim();
        if (t && !isLabel(t) && t.length < 300) return t;
      }
    }

    // 2. Next sibling
    let next = labelEl.nextElementSibling;
    let attempts = 3;
    while (next && attempts > 0) {
      const t = next.textContent.trim();
      if (t && !isLabel(t) && t.length > 1 && t.length < 300) return t;
      next = next.nextElementSibling;
      attempts--;
    }

    // 3. dt -> dd pattern
    if (labelEl.tagName === 'DT' && labelEl.nextElementSibling && labelEl.nextElementSibling.tagName === 'DD') {
      return labelEl.nextElementSibling.textContent.trim();
    }

    // 4. Parent's next sibling
    if (labelEl.parentElement) {
      const parentNext = labelEl.parentElement.nextElementSibling;
      if (parentNext) {
        const t = parentNext.textContent.trim();
        if (t && !isLabel(t) && t.length < 300) return t;
      }
    }

    return null;
  }

  function splitAddress(addr) {
    const cleaned = addr.replace(/\s{2,}/g, ' ').trim();
    if (cleaned.includes('\n')) {
      const lines = cleaned.split('\n').map(l => l.trim()).filter(Boolean);
      if (lines.length >= 2) {
        return {
          street: lines.slice(0, -1).join(' '),
          cityState: lines[lines.length - 1]
        };
      }
    }
    // Try to detect "STREET, CITY, ST ZIP" or "STREET CITY ST ZIP"
    const m = cleaned.match(/^(.+?)[\s,]+([A-Za-z][A-Za-z\s\-\.]+?),?\s+([A-Z]{2})(?:\s+(\d{5}(?:-\d{4})?))?$/);
    if (m) {
      return {
        street: m[1].trim(),
        cityState: `${m[2].trim()}, ${m[3]}`
      };
    }
    return null;
  }

  /* ---- Sunbiz-specific parser (has consistent structure) ---- */
  function extractFromSunbiz() {
    const url = window.location.href;
    if (!url.includes('sunbiz.org')) return null;
    const result = { _isSunbiz: true };

    // Entity name
    const entityNameEl = document.querySelector('.detailSection p, .corporationName p');
    if (entityNameEl) result.entityName = entityNameEl.textContent.trim();

    // Walk text and pull principal officers
    const text = document.body.innerText;
    const lines = text.split(/\n+/).map(l => l.trim()).filter(Boolean);

    // Find sections like "Officer/Director Detail" or "Authorized Person(s) Detail"
    // Each principal entry is: Title XYZ\nName SURNAME, FIRST\n[address lines]
    const principals = [];
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].match(/^Title\s+(.+)$/);
      if (m) {
        const title = m[1].trim();
        // Next line should be name
        if (lines[i + 1] && lines[i + 1].match(/^Name\s+/)) {
          const nameLine = lines[i + 1].replace(/^Name\s+/, '').trim();
          // Address often on next 1-2 lines
          let address = '';
          for (let j = i + 2; j < Math.min(i + 5, lines.length); j++) {
            if (lines[j].match(/^Title\s+/) || lines[j].match(/^Name\s+/)) break;
            if (lines[j].length > 200) break;
            address += (address ? ' ' : '') + lines[j];
          }
          principals.push({ title, name: nameLine, address });
        }
      }
    }
    result.principals = principals;

    // Registered agent
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].match(/Registered Agent Name/i)) {
        // Next non-empty line
        for (let j = i + 1; j < Math.min(i + 4, lines.length); j++) {
          if (lines[j] && lines[j].length > 2 && lines[j].length < 100) {
            result.registeredAgent = lines[j].trim();
            break;
          }
        }
      }
    }

    // Pre-fill the popup with the first principal as a candidate
    if (principals.length > 0) {
      const top = principals[0];
      // Convert "SMITH, JOHN" to "JOHN SMITH" for better people search
      let personName = top.name;
      if (personName.includes(',')) {
        const parts = personName.split(',').map(s => s.trim());
        if (parts.length === 2) personName = `${parts[1]} ${parts[0]}`;
      }
      result.ownerName = personName;
      if (top.address) {
        const split = splitAddress(top.address);
        if (split) {
          result.mailingAddress = split.street;
          result.cityState = split.cityState;
        } else {
          result.mailingAddress = top.address;
        }
      }
    }

    return result;
  }

  /* ---- Selection-based extraction (fallback) ---- */
  function extractFromSelection() {
    const sel = window.getSelection().toString().trim();
    if (!sel || sel.length > 500) return null;
    const lines = sel.split(/\n+/).map(l => l.trim()).filter(Boolean);
    if (lines.length === 0) return null;
    const result = { ownerName: lines[0] };
    if (lines.length > 1) {
      const split = splitAddress(lines.slice(1).join('\n'));
      if (split) {
        result.mailingAddress = split.street;
        result.cityState = split.cityState;
      } else {
        result.mailingAddress = lines.slice(1).join(' ');
      }
    }
    return result;
  }

  /* ---- PHONE SCANNER ---- */
  function scanPhones() {
    const phones = new Map();

    // 1. tel: links — strongest signal
    document.querySelectorAll('a[href^="tel:"]').forEach(a => {
      const raw = a.href.replace(/^tel:/i, '').replace(/\D/g, '');
      if (raw.length === 10 || (raw.length === 11 && raw[0] === '1')) {
        const num = raw.length === 11 ? raw.slice(1) : raw;
        if (!isValidAreaCode(num.slice(0, 3))) return;
        const formatted = `(${num.slice(0, 3)}) ${num.slice(3, 6)}-${num.slice(6)}`;
        if (!phones.has(formatted)) {
          let context = a.textContent.trim() || (a.parentElement?.textContent || '').trim();
          context = context.replace(/\s+/g, ' ').slice(0, 120);
          phones.set(formatted, { context, source: 'tel' });
        }
      }
    });

    // 2. Text patterns — visible page text only
    const text = document.body.innerText;
    // (XXX) XXX-XXXX, XXX-XXX-XXXX, XXX.XXX.XXXX, +1 XXX XXX XXXX
    const phoneRegex = /(?:\+?1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?(\d{3})[-.\s]?(\d{4})\b/g;
    let m;
    while ((m = phoneRegex.exec(text)) !== null) {
      const area = m[1], mid = m[2], end = m[3];
      const formatted = `(${area}) ${mid}-${end}`;
      if (phones.has(formatted)) continue;

      // Filters for obvious junk
      if (mid === '555' && (end.startsWith('01') || end === '0100')) continue;
      if (area === '000' || area === '111') continue;
      if (area === mid && mid === end.slice(0, 3)) continue; // 222-222-2222 etc.
      if (!isValidAreaCode(area)) continue;

      const start = Math.max(0, m.index - 70);
      const stop = Math.min(text.length, m.index + m[0].length + 70);
      const context = text.slice(start, stop).replace(/\s+/g, ' ').trim();

      phones.set(formatted, { context, source: 'text' });
    }

    return Array.from(phones.entries()).map(([phone, info]) => ({
      phone,
      context: info.context,
      source: info.source
    }));
  }

  function isValidAreaCode(area) {
    // North American area codes start with 2-9, second digit can be anything,
    // third digit can be anything. We just exclude obvious junk.
    if (!/^[2-9]\d\d$/.test(area)) return false;
    return true;
  }

  /* ---- DISPATCH ---- */
  const sunbiz = extractFromSunbiz();
  if (sunbiz && sunbiz.principals && sunbiz.principals.length > 0) {
    return { ...sunbiz, _phones: scanPhones() };
  }

  const sel = extractFromSelection();
  if (sel) {
    return { ...sel, _phones: scanPhones(), _fromSelection: true };
  }

  const generic = extractGeneric();
  return { ...generic, _phones: scanPhones() };
}

/* ===========================================================
   POPUP-SIDE LOGIC
   =========================================================== */

async function extractFromPage() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    flashHint('extractHint', 'No active tab found.', false);
    return;
  }
  // Don't try to inject into chrome:// or extension pages
  if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://') || tab.url.startsWith('about:'))) {
    flashHint('extractHint', 'Cannot run on browser internal pages. Open a tax card or website tab first.', false);
    return;
  }

  try {
    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: pageExtractor,
    });
    const data = result.result || {};

    let extractedSomething = false;
    if (data.ownerName) { $('ownerName').value = data.ownerName; extractedSomething = true; }
    if (data.mailingAddress) { $('mailingAddress').value = data.mailingAddress; extractedSomething = true; }
    if (data.cityState) { $('cityState').value = data.cityState; extractedSomething = true; }
    if (data.propertyAddress) { $('propertyAddress').value = data.propertyAddress; extractedSomething = true; }

    updateEntityHint();
    persistInputs();

    // Always render any phones found on the page
    if (data._phones && data._phones.length) {
      renderPhones(data._phones);
    }

    if (data._isSunbiz && data.principals && data.principals.length > 1) {
      flashHint('extractHint', `Sunbiz: pulled ${data.principals.length} principals — top one loaded above. Open Sunbiz tab to see the rest.`, true);
    } else if (data._isSunbiz && data.principals && data.principals.length === 1) {
      flashHint('extractHint', `Sunbiz principal extracted — search them next.`, true);
    } else if (data._fromSelection) {
      flashHint('extractHint', `Used your text selection.`, true);
    } else if (extractedSomething) {
      flashHint('extractHint', `Auto-extracted from page.`, true);
    } else if (data._phones && data._phones.length) {
      flashHint('extractHint', `No owner info found, but pulled ${data._phones.length} phones from the page.`, true);
    } else {
      flashHint('extractHint', `Couldn't find owner info. Try selecting it on the page first, then click again — or enter manually.`, false);
    }
  } catch (e) {
    flashHint('extractHint', `Extract failed: ${e.message}. Try entering manually.`, false);
  }
}

async function scanPageForPhones() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;
  if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://'))) {
    flashHint('extractHint', 'Cannot scan browser internal pages.', false);
    return;
  }
  try {
    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: pageExtractor,
    });
    const data = result.result || {};
    const phones = data._phones || [];
    renderPhones(phones);
  } catch (e) {
    renderPhones([]);
  }
}

/* ---- Phone list rendering ---- */
function renderPhones(phones) {
  const list = $('phoneList');
  list.innerHTML = '';
  $('phoneCount').textContent = '';

  if (!phones || phones.length === 0) {
    list.innerHTML = '<div class="phone-empty">No phones found on this page.</div>';
    return;
  }

  // Update count badge in captured area
  $('phoneCount').textContent = `· ${phones.length} on page`;

  phones.forEach(({ phone, context, source }) => {
    const row = document.createElement('div');
    row.className = 'phone-row';

    const info = document.createElement('div');
    info.className = 'phone-info';
    const num = document.createElement('div');
    num.className = 'phone-number';
    num.textContent = phone;
    if (source === 'tel') {
      const tag = document.createElement('span');
      tag.className = 'phone-tag';
      tag.textContent = 'tel:';
      num.appendChild(tag);
    }
    info.appendChild(num);

    const ctx = document.createElement('div');
    ctx.className = 'phone-context';
    ctx.textContent = context.length > 90 ? context.slice(0, 90) + '…' : context;
    info.appendChild(ctx);

    const btn = document.createElement('button');
    btn.className = 'phone-copy';
    btn.textContent = 'copy';
    btn.addEventListener('click', async () => {
      await navigator.clipboard.writeText(phone);
      btn.textContent = '✓';
      btn.classList.add('copied');
      // Also append to captured pad
      const ta = $('capturedNumbers');
      const existing = ta.value.trim();
      if (!existing.includes(phone)) {
        ta.value = existing ? existing + '\n' + phone : phone;
        persistCaptured();
      }
      setTimeout(() => {
        btn.textContent = 'copy';
        btn.classList.remove('copied');
      }, 1200);
    });

    row.appendChild(info);
    row.appendChild(btn);
    list.appendChild(row);
  });
}

/* ---- Hints / flashes ---- */
function flashHint(elId, message, success) {
  const el = $(elId);
  el.textContent = message;
  el.classList.add('show');
  if (success) el.classList.add('success');
  else el.classList.remove('success');
  clearTimeout(el._t);
  el._t = setTimeout(() => {
    el.classList.remove('show');
  }, 5500);
}

function updateEntityHint() {
  const name = $('ownerName').value.trim();
  const hint = $('entityHint');
  if (isLikelyEntity(name)) {
    hint.textContent = '⚐ Detected as business entity — start with Sunbiz to find the principal/manager. The Sunbiz button below is your first call.';
    hint.classList.add('show');
  } else {
    hint.classList.remove('show');
  }
}

/* ---- Captured numbers ---- */
function formatPhoneNumbers() {
  const text = $('capturedNumbers').value;
  const phoneRegex = /(?:\+?1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?(\d{3})[-.\s]?(\d{4})\b/g;
  const formatted = text.replace(phoneRegex, '($1) $2-$3');
  $('capturedNumbers').value = formatted;
  persistCaptured();
}

async function copyAll() {
  const text = $('capturedNumbers').value;
  if (!text.trim()) return;
  await navigator.clipboard.writeText(text);
  const btn = $('copyAllBtn');
  const original = btn.textContent;
  btn.textContent = '✓ Copied';
  setTimeout(() => btn.textContent = original, 1500);
}

function clearCaptured() {
  if (!confirm('Clear captured notes?')) return;
  $('capturedNumbers').value = '';
  persistCaptured();
}

/* ---- Persistence ---- */
async function persistInputs() {
  await chrome.storage.local.set({
    inputs: {
      ownerName: $('ownerName').value,
      mailingAddress: $('mailingAddress').value,
      cityState: $('cityState').value,
      propertyAddress: $('propertyAddress').value,
    }
  });
}

async function loadInputs() {
  const { inputs = {} } = await chrome.storage.local.get('inputs');
  if (inputs.ownerName) $('ownerName').value = inputs.ownerName;
  if (inputs.mailingAddress) $('mailingAddress').value = inputs.mailingAddress;
  if (inputs.cityState) $('cityState').value = inputs.cityState;
  if (inputs.propertyAddress) $('propertyAddress').value = inputs.propertyAddress;
  updateEntityHint();
}

async function persistCaptured() {
  await chrome.storage.local.set({ captured: $('capturedNumbers').value });
}

async function loadCaptured() {
  const { captured = '' } = await chrome.storage.local.get('captured');
  $('capturedNumbers').value = captured;
}

/* ---- History ---- */
async function saveToHistory(name, source) {
  const { history = [] } = await chrome.storage.local.get('history');
  const idx = history.findIndex(h => h.name.toLowerCase() === name.toLowerCase());
  if (idx >= 0) {
    history[idx].sources = Array.from(new Set([...history[idx].sources, source]));
    history[idx].lastSearched = Date.now();
    history[idx].count = (history[idx].count || 1) + 1;
    // Move to top
    const item = history.splice(idx, 1)[0];
    history.unshift(item);
  } else {
    history.unshift({
      name,
      sources: [source],
      lastSearched: Date.now(),
      count: 1
    });
  }
  const trimmed = history.slice(0, 30);
  await chrome.storage.local.set({ history: trimmed });
  renderHistory();
}

async function renderHistory() {
  const { history = [] } = await chrome.storage.local.get('history');
  $('historyCount').textContent = history.length;
  const list = $('historyList');
  list.innerHTML = '';
  if (history.length === 0) {
    list.innerHTML = '<div style="padding: 8px 4px; color: var(--muted-2); font-size: 11px; font-style: italic;">No lookups yet.</div>';
    return;
  }
  history.forEach(h => {
    const item = document.createElement('div');
    item.className = 'history-item';
    const date = new Date(h.lastSearched);
    const dateStr = date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    const timeStr = date.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

    const nameEl = document.createElement('div');
    nameEl.className = 'history-name';
    nameEl.textContent = h.name;
    const meta = document.createElement('div');
    meta.className = 'history-meta';
    meta.textContent = `${dateStr} · ${timeStr} · ${h.sources.length} ${h.sources.length === 1 ? 'source' : 'sources'}`;

    item.appendChild(nameEl);
    item.appendChild(meta);
    item.addEventListener('click', () => {
      $('ownerName').value = h.name;
      updateEntityHint();
      persistInputs();
    });
    list.appendChild(item);
  });
}

async function clearHistory() {
  if (!confirm('Clear all search history?')) return;
  await chrome.storage.local.set({ history: [] });
  renderHistory();
}

/* ===========================================================
   INIT
   =========================================================== */

document.addEventListener('DOMContentLoaded', () => {
  // Buttons
  $('extractBtn').addEventListener('click', extractFromPage);
  $('scanBtn').addEventListener('click', scanPageForPhones);
  $('openAllBtn').addEventListener('click', openAllSources);
  $('formatBtn').addEventListener('click', formatPhoneNumbers);
  $('copyAllBtn').addEventListener('click', copyAll);
  $('clearBtn').addEventListener('click', clearCaptured);
  $('clearHistoryBtn').addEventListener('click', clearHistory);

  // Search buttons
  document.querySelectorAll('.search-btn').forEach(btn => {
    btn.addEventListener('click', () => openSearch(btn.dataset.source));
  });

  // Input persistence
  ['ownerName', 'mailingAddress', 'cityState', 'propertyAddress'].forEach(id => {
    $(id).addEventListener('input', () => {
      if (id === 'ownerName') updateEntityHint();
      persistInputs();
    });
  });

  $('capturedNumbers').addEventListener('input', persistCaptured);

  // Load persisted state
  loadInputs();
  loadCaptured();
  renderHistory();
});
